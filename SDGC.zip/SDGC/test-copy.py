import networkx as nx
import matplotlib.pyplot as plt
import matplotlib
import scipy.io
import h5py
import math
from scipy.stats import kendalltau
from sklearn.metrics import auc
from scipy.signal import savgol_filter
import seaborn as sns
import matplotlib.cm as cm
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from scipy.interpolate import interp1d
from matplotlib.patches import Rectangle
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.transforms as mtransforms
import json
from matplotlib.font_manager import FontProperties


# 设置字体
matplotlib.rcParams['font.family'] = 'Microsoft YaHei'  # 或者 'Microsoft YaHei'
matplotlib.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

from gravity import calculate_centrality
from EGM import run_EGM_method
from LGC import calculate_lgc
from origravity import calculate_origravity_centrality
from FGM import run_FGM_method,calculate_node_weights, calculate_fusion_values, calculate_FGM_centrality
from AOGC import AOGC
from collections import Counter



file_path = 'facebook_combined.txt'
def load_graph_from_file(file_path):
    G = nx.Graph()
    with open(file_path, 'r') as f:
        for line in f:
            node1, node2 = map(int, line.strip().split())
            G.add_edge(node1, node2)
    return G
G = load_graph_from_file(file_path)

# G = nx.les_miserables_graph()




# # 获取数据集名称
# dataset_name = file_path.split('/')[-1]



# #
# file_path = 'Email.gml'
# G = nx.read_gml(file_path)


# dataset_name = file_path.split('/')[-1]


alpha = 0.56
G.remove_edges_from(nx.selfloop_edges(G))

#####计算网络的 β 阈值
def calculate_beta_threshold(G):
    degree_sequence = [degree for node, degree in G.degree()]
    avg_k = np.mean(degree_sequence)
    avg_k2 = np.mean([k**2 for k in degree_sequence])
    beta_th = avg_k / (avg_k2 - avg_k)
    return beta_th

beta_th = calculate_beta_threshold(G)
print("流行病阈值 βth:", beta_th)




# centrality_values =calculate_centrality(G, alpha)
##先进方法
# EGM_centrality_values = run_EGM_method(G)
# print("\n读取的中心性值:")
# lgc_centrality = calculate_lgc(G)
# print("\n读取的中心性值:")
# origravity_centrality = calculate_origravity_centrality(G)
# print("\n读取的中心性值:")
#
# FGM_centrality_values = run_FGM_method(G)
# print("\n读取的中心性值:")
# AOGC_centrality_values=AOGC(G)


# #基础方法
# degree_centrality = nx.degree_centrality(G)
# closeness_centrality = nx.closeness_centrality(G)
# # pagerank_centrality = nx.pagerank(G)
# betweenness_centrality = nx.betweenness_centrality(G)
# k_shell_centrality = nx.core_number(G)



# 计算节点权重
# node_weights = calculate_node_weights(G)
# print("节点权重：", node_weights)
#
# # 计算融合值
# fusion_values = calculate_fusion_values(G)
# print("融合值：", fusion_values)
#
# # 计算 FGM 中心性值
# FGM_centrality_values = calculate_FGM_centrality(G)
# print("FGM 中心性值：", FGM_centrality_values)
#
# print("FGM中心性值：")
# for node, value in FGM_centrality_values.items():
#     print(f"节点 {node}: FGM 中心性值 {value}")



#####肯德尔系数
# 模拟 SI 模型
# SI模型实验参数

# 计算网络的 β 阈值
# def calculate_beta_threshold(G):
#     degree_sequence = [degree for node, degree in G.degree()]
#     avg_k = np.mean(degree_sequence)
#     avg_k2 = np.mean([k**2 for k in degree_sequence])
#     beta_th = avg_k / (avg_k2 - avg_k)
#     return beta_th
#
# beta_th = calculate_beta_threshold(G)
# print("流行病阈值 βth:", beta_th)
#
# beta_values = np.linspace(beta_th, beta_th*2,5)
# num_experiments = 100
# max_steps = 12  # 最大时间步
#
#
#
# # SI模型模拟函数
# def simulate_SI_model(G, initial_infected_nodes, beta, max_steps=12):
#     infected = set(initial_infected_nodes)  # 已感染节点集合
#     total_infected_curve = np.zeros(len(G))  # 记录每个节点的感染次数
#
#     for step in range(max_steps):
#         new_infected = set()
#
#         # 遍历已经感染的节点
#         for node in infected:
#             neighbors = list(G.neighbors(node))
#
#             # 遍历邻居并随机判断是否感染
#             for neighbor in neighbors:
#                 if neighbor not in infected and np.random.rand() < beta:
#                     new_infected.add(neighbor)
#
#         # 更新感染状态
#         for node in new_infected:
#             total_infected_curve[list(G.nodes()).index(node)] += 1
#
#         infected.update(new_infected)
#
#     return total_infected_curve
#
# # 运行SI模型实验，生成标准序列，并记录每个beta值下的感染能力
# def run_SI_experiment(G, beta_values, num_experiments, max_steps):
#     infection_abilities = {}  # 用于存储不同 beta 下每个节点的感染能力
#     si_standard_sequences = []
#
#     for idx, beta in enumerate(beta_values):
#         infection_abilities[idx] = {node: 0 for node in G.nodes()}
#
#         for _ in range(num_experiments):
#             for node in G.nodes():
#                 # 单个节点为初始感染者，运行SI模型
#                 infection_ability = simulate_SI_model(G, [node], beta, max_steps)
#
#                 # 更新感染能力
#                 for i, node_in_graph in enumerate(G.nodes()):
#                     infection_abilities[idx][node_in_graph] += infection_ability[i]
#
#         # 计算每个节点的平均感染能力
#         for node in G.nodes():
#             infection_abilities[idx][node] /= num_experiments
#
#         # 直接存储节点的感染能力序列（不再排序）
#         si_standard_sequences.append(list(infection_abilities[idx].values()))
#
#     return si_standard_sequences, infection_abilities
#
# # 调用实验并输出感染能力和标准序列
# si_standard_sequences, infection_abilities = run_SI_experiment(G, beta_values, num_experiments, max_steps)
#
# # # 各种中心性方法的定义
# centrality_methods = {
#     'SDGC': centrality_values,
#     'DC': degree_centrality,
#     'CC': closeness_centrality,
#     # 'PR': pagerank_centrality,
#     'BC': betweenness_centrality,
#     'KS': k_shell_centrality,
#     'GC': origravity_centrality,
#     'EGM': EGM_centrality_values,
#     'LGC': lgc_centrality,
#     'AOGC':AOGC_centrality_values,
#     'FGM': FGM_centrality_values,
# }
#
# # 计算肯德尔系数
# kendall_results = {method: [] for method in centrality_methods}
#
# for beta_index, si_sequence in enumerate(si_standard_sequences):
#     print(f"\nFor infection rate β = {beta_values[beta_index]:.4f}:")
#
#     for method_name, centrality in centrality_methods.items():
#         centrality_values = list(centrality.values())
#
#         # 确保序列长度相同再计算Kendall's Tau
#         if len(si_sequence) == len(centrality_values):
#             tau, _ = kendalltau(si_sequence, centrality_values)
#             kendall_results[method_name].append(tau)
#             print(f"{method_name}: τ = {tau:.4f}")
#         else:
#             print(f"序列长度不一致，无法计算{method_name}方法的τ值。")
#
# # 绘制Kendall系数随beta变化的折线图
# for method_name, tau_values in kendall_results.items():
#     plt.plot(beta_values, tau_values, label=method_name)  # 为每条线添加标签
#
# plt.xlabel('Infection Rate β')
# plt.ylabel("Kendall's Tau Coefficient")
# # plt.title(f'Network: {dataset_name}')
# plt.legend(loc='upper left')  # 将图例放置在左上角
# plt.grid(True)  # 显示网格
# plt.show()






# def save_experiment_data(efficiency_data, filename):
#     with open(filename, 'w') as f:
#         json.dump(efficiency_data, f)
#
#
# # 加载实验数据
# def load_experiment_data(filename):
#     with open(filename, 'r') as f:
#         return json.load(f)

# centrality_methods = {
#     'SDGC': centrality_values,
#     'DC': degree_centrality,
#     'CC': closeness_centrality,
#     # 'PR': pagerank_centrality,
#     'BC': betweenness_centrality,
#     'KS': k_shell_centrality,
#     'GC': origravity_centrality,
#     'EGM': EGM_centrality_values,
#     'LGC': lgc_centrality,
#     'AOGC': AOGC_centrality_values,
#     'FGM': FGM_centrality_values,
# }
# # 评估并保存实验数据
# def run_experiment_and_save(G, centrality_methods, top_percent=70, num_remove=10, filename="experiment_data.json"):
#     experiment_data = {}
#
#     for method_name, centrality in centrality_methods.items():
#         # 评估每个方法的节点移除对网络效率的影响
#         efficiency_decrease = evaluate_node_removal_optimized(G, centrality, top_percent, num_remove)
#
#         # 保存每个方法的效率下降值
#         experiment_data[method_name] = efficiency_decrease
#
#     # 保存实验数据
#     save_experiment_data(experiment_data, filename)
#
# #
# def calculate_efficiency_from_shortest_paths(shortest_paths, G):
#     n = len(G.nodes())
#     if n <= 1:
#         return 0
#     efficiency_sum = 0
#     for node1 in G.nodes():
#         for node2 in G.nodes():
#             if node1 != node2:
#                 try:
#                     shortest_path = shortest_paths[node1][node2]
#                     efficiency_sum += 1 / shortest_path
#                 except (KeyError, nx.NetworkXNoPath):
#                     continue
#     return efficiency_sum / (n * (n - 1))
#
# #
# # # 评估节点移除对网络效率的影响，基于预先计算好的最短路径
# def evaluate_node_removal_optimized(G, centrality, top_percent=70, num_remove=10):
#     G_copy = G.copy()  # 复制原图以进行移除操作
#     # 计算原图的初始网络效率
#     shortest_paths = dict(nx.all_pairs_shortest_path_length(G_copy))  # 预先计算所有最短路径
#     initial_efficiency = calculate_efficiency_from_shortest_paths(shortest_paths, G_copy)
#
#     # 按照中心性值排序，取排名前 num_remove 个节点
#     sorted_nodes = sorted(centrality.items(), key=lambda item: item[1], reverse=True)
#     top_nodes = [node for node, _ in sorted_nodes[:num_remove]]
#
#     efficiency_decrease = []  # 存储每次移除后的效率下降值
#
#     for node in top_nodes:
#         G_copy.remove_node(node)  # 移除节点
#         # 只计算剩余节点对之间的效率
#         if len(G_copy) > 1:  # 确保移除后图仍然有节点
#             # 局部更新最短路径（只更新与该节点相关的路径）
#             shortest_paths = dict(nx.all_pairs_shortest_path_length(G_copy))  # 可以使用增量更新最短路径
#             current_efficiency = calculate_efficiency_from_shortest_paths(shortest_paths, G_copy)
#             decrease = initial_efficiency - current_efficiency  # 计算效率下降值
#             efficiency_decrease.append(decrease)  # 存储效率下降值
#         else:
#             efficiency_decrease.append(initial_efficiency)  # 如果剩余节点不足以计算效率，则保持原效率
#
#     return efficiency_decrease
#
# #
# #
# # 执行实验并保存结果
# run_experiment_and_save(G, centrality_methods, top_percent=70, num_remove=200, filename=r"img\efficiency\facebook.json")


# 绘制效率曲线
# def plot_network_efficiency_with_inset(filename, show_inset=True):
#     plt.figure(figsize=(10, 8), dpi=360)
#     method_count = 0
#
#     # 读取实验数据
#     experiment_data = load_experiment_data(filename)
#
#     colors = ['red', 'royalblue', 'mediumslateblue', 'darkcyan',
#               'green', 'darkmagenta', 'crimson', 'yellowgreen',
#               'indianred', 'deepskyblue']
#
#     linestyles = ['--']
#     markers = ['o', 's', 'D', '^', 'v', '<', '>', 'p', '*', 'X']
#
#     # 绘制主图
#     for method_name, efficiency_decrease in experiment_data.items():
#         # 设置颜色、线型
#         color = colors[method_count % len(colors)]
#         linestyle = linestyles[method_count % len(linestyles)]
#         marker = markers[method_count % len(markers)]
#
#         # 横坐标从“节点数量”转换为“节点数量所占总数的比例”
#         x_values = [i + 1 for i in range(len(efficiency_decrease))]  # 确保x轴从1开始
#
#         plt.plot(
#             x_values,
#             efficiency_decrease,
#             label=f'{method_name}',
#             color=color,
#             linestyle=linestyle,
#             linewidth=6,
#             marker=marker,
#             markevery=10,
#             markersize=11,
#             markerfacecolor='none',
#             markeredgewidth=3
#         )
#         method_count += 1
#
#     # 设置主图的标签和标题
#     plt.xlabel('Number of Nodes Removed', fontsize=24, fontweight='bold')
#     plt.ylabel('Decline Rate of Network Efficiency', fontsize=24, fontweight='bold')
#     plt.title('Facebook', fontsize=24, fontweight='bold')
#
#     font = FontProperties()
#     font.set_weight('heavy')
#     font.set_size(18)
#
#     # 设置图例
#     # plt.legend(loc='best', framealpha=0.7, prop=font)
#
#     plt.tight_layout()
#
#     ##调整刻度标签的字体大小和加粗
#     plt.tick_params(axis='both', direction='in', labelsize=19, width=3)
#
#     plt.xticks(fontsize=26, fontweight='black', family='Times New Roman')
#     plt.yticks(fontsize=26, fontweight='black', family='Times New Roman')
#
#     plt.subplots_adjust(left=0.13, right=0.98, top=0.95, bottom=0.1)
#
#     plt.xlim(left=1)
#     plt.ylim(bottom=-0.002)
#
#     # 添加嵌入式缩略图
#
#
#     # 增加坐标轴框的线宽
#     plt.gca().spines['top'].set_linewidth(2.5)
#     plt.gca().spines['right'].set_linewidth(2.5)
#     plt.gca().spines['left'].set_linewidth(2.5)
#     plt.gca().spines['bottom'].set_linewidth(2.5)
#
#     # 显示图表
#     plt.show()
#
# # 直接加载已保存的实验数据
# plot_network_efficiency_with_inset(filename=r"img/efficiency/facebook.json", show_inset=False)











####
# def calculate_efficiency_from_shortest_paths(shortest_paths, G):
#     n = len(G.nodes())
#     if n <= 1:
#         return 0
#     efficiency_sum = 0
#     for node1 in G.nodes():
#         for node2 in G.nodes():
#             if node1 != node2:
#                 try:
#                     shortest_path = shortest_paths[node1][node2]
#                     efficiency_sum += 1 / shortest_path
#                 except (KeyError, nx.NetworkXNoPath):
#                     continue
#     return efficiency_sum / (n * (n - 1))
#
#
# # 评估节点移除对网络效率的影响，基于预先计算好的最短路径
# def evaluate_node_removal_optimized(G, centrality, top_percent=70):
#     G_copy = G.copy()  # 复制原图以进行移除操作
#     shortest_paths = dict(nx.all_pairs_shortest_path_length(G_copy))  # 预先计算所有最短路径
#
#     # 按照中心性值排序，取排名前 top_percent%的节点
#     sorted_nodes = sorted(centrality.items(), key=lambda item: item[1], reverse=True)
#     top_nodes_count = int(len(sorted_nodes) * top_percent / 100)
#     top_nodes = [node for node, _ in sorted_nodes[:top_nodes_count]]
#
#     efficiency = []
#
#     for node in top_nodes:
#         G_copy.remove_node(node)  # 移除节点
#         # 只计算剩余节点对之间的效率
#         if len(G_copy) > 1:  # 确保移除后图仍然有节点
#             shortest_paths = dict(nx.all_pairs_shortest_path_length(G_copy))  # 更新最短路径
#             efficiency.append(calculate_efficiency_from_shortest_paths(shortest_paths, G_copy))
#         else:
#             efficiency.append(0)
#
#     return efficiency
#
#
# # 评估不同中心性方法
# centrality_methods = {
#     'SDGC': centrality_values,
#     'DC': degree_centrality,
#     'CC': closeness_centrality,
#     # 'PR': pagerank_centrality,
#     'BC': betweenness_centrality,
#     'KS': k_shell_centrality,
#     'GC': origravity_centrality,
#     'EGM': EGM_centrality_values,
#     'LGC': lgc_centrality,
#     'AOGC': AOGC_centrality_values,
#     'FGM': FGM_centrality_values,
# }
#
#
# # 绘制效率曲线
# def plot_network_efficiency_with_inset(centrality_methods, show_inset=True, top_percent=70, total_nodes=None):
#     plt.figure(figsize=(8, 7), dpi=300)
#     method_count = 0
#
#     colors = ['b', 'g', 'r', 'c', 'm', 'y', 'k']  # 与SI实验相同的颜色系列
#     linestyles = ['-', '--']
#
#     # 绘制主图
#     for method_name, centrality in centrality_methods.items():
#         efficiency_eval = evaluate_node_removal_optimized(G, centrality, top_percent)
#
#         # 设置颜色、线型
#         color = colors[method_count % len(colors)]  # 使用提供的颜色系列
#         linestyle = linestyles[method_count % len(linestyles)]
#
#         # 将横坐标从“节点数量”转换为“节点数量所占总数的比例”
#         x_values = [i / total_nodes for i in range(len(efficiency_eval))]
#
#         plt.plot(
#             x_values,
#             efficiency_eval,
#             label=f'{method_name}',
#             color=color,
#             linestyle=linestyle,
#             markevery=5,
#             markersize=8,
#             linewidth=2
#         )
#         method_count += 1
#
#     # 设置主图的标签和标题
#     plt.xlabel('Fraction of Nodes Removed', fontsize=16)
#     plt.ylabel('Network Efficiency', fontsize=16)
#     plt.title('GrQc', fontsize=16)
#     plt.legend(loc='upper right', framealpha=0.7, fontsize=12)  # 图例放在主图内
#     plt.tick_params(axis='both', direction='in')  # 刻度朝内
#     plt.tight_layout()
#
#     # 强制显示 0 刻度并留有一定空间
#     plt.xlim(left=-0.01)  # 横坐标范围从0到1，表示0%到100%的节点移除比例
#     plt.ylim(bottom=-0.02)  # 上边界稍微留点空间，底部留空
#
#     # 添加嵌入式缩略图（根据 show_inset 参数决定是否绘制）
#     if show_inset:
#         ax_inset = inset_axes(plt.gca(), width="40%", height="40%", loc='upper right', borderpad=3)
#
#         # 重置计数器以确保嵌入图与主图样式一致
#         method_count = 0
#         for method_name, centrality in centrality_methods.items():
#             efficiency_eval = evaluate_node_removal_optimized(G, centrality, top_percent)
#
#             # 复用主图的颜色、线型
#             color = colors[method_count % len(colors)]
#             linestyle = linestyles[method_count % len(linestyles)]
#
#             # 将横坐标从“节点数量”转换为“节点数量所占总数的比例”
#             x_values = [i / total_nodes for i in range(len(efficiency_eval))]
#
#             ax_inset.plot(
#                 x_values,
#                 efficiency_eval,
#                 label=f'{method_name}',
#                 color=color,
#                 linestyle=linestyle,
#                 linewidth=2
#             )
#             method_count += 1
#
#         # 设置嵌入式缩略图的坐标轴范围
#         ax_inset.set_xlim(0, 0.4)  # 放大 x 轴的某个区域
#         ax_inset.set_ylim(0.05, 0.4)  # 放大 y 轴的某个区域
#         ax_inset.grid(True, which='both', linestyle='--', linewidth=0.6)
#
#         # 同步图例（如果不希望嵌入图单独显示图例）
#         ax_inset.legend().set_visible(False)
#
#     plt.show()
#
#
#
# total_nodes = len(G.nodes())  # 假设 G 是你的图，获取图的节点总数
# plot_network_efficiency_with_inset(centrality_methods, show_inset=False, top_percent=75, total_nodes=total_nodes)




# def calculate_uniqueness(centrality_scores, p=1):
#
#     if isinstance(centrality_scores, dict):
#         centrality_values = list(centrality_scores.values())
#     else:
#         centrality_values = centrality_scores
#
#     N = len(centrality_values)  # 总节点数
#     score_counts = Counter(centrality_values)  # 统计得分出现的次数
#
#     # 计算独特性分数 UI
#     UI = 0
#     for score in centrality_values:
#         NumSame = score_counts[score]  # 与当前节点得分相同的节点数
#         UI += (1 - (NumSame / N)) ** p
#
#     UI /= N  # 归一化
#     return UI
#
#
# # def calculate_individuation(centrality_values):
# #
# #     if isinstance(centrality_values, dict):
# #         centrality_values = np.array(list(centrality_values.values()))
# #
# #     Nu = len(np.unique(centrality_values))  # 唯一分数节点数
# #     N = len(centrality_values)  # 总节点数
# #     return Nu / N
# #
# #
# #
# def calculate_monotonicity(centrality_values):
#
#     if isinstance(centrality_values, dict):
#         centrality_values = np.array(list(centrality_values.values()))
#
#     sorted_values = np.sort(centrality_values)
#     unique_values, counts = np.unique(sorted_values, return_counts=True)
#     total_nodes = len(centrality_values)
#
#     numerator = np.sum(counts * (counts - 1))  # 分子
#     denominator = total_nodes * (total_nodes - 1)  # 分母
#     return (1 - numerator / denominator) ** 2
#
# # 包含所有中心性方法的字典
# centrality_methods = {
#     'SDGC': centrality_values,
#     'DC': degree_centrality,
#     'CC': closeness_centrality,
#     'BC': betweenness_centrality,
#     'KS': k_shell_centrality,
#     'GC': origravity_centrality,
#     'EGM': EGM_centrality_values,
#     'LGC': lgc_centrality,
#     'AOGC': AOGC_centrality_values,
#     'FGM': FGM_centrality_values,
# }
#
# # 存储每个方法的结果
# results = {
#     # 'Individuation': {},
#     'Uniqueness': {},
#     'Monotonicity': {}
# }
#
# # 计算所有指标
# for method_name, centrality_values in centrality_methods.items():
#     try:
#         # 计算个体化值
#         # Fre = calculate_individuation(centrality_values)
#         # # 计算单调性
#         # M_R = calculate_monotonicity(centrality_values)
#         # # 计算独特性分数
#         UI = calculate_uniqueness(centrality_values, p=2)
#
#         # 存储结果
#         # results['Individuation'][method_name] = Fre
#         # results['Monotonicity'][method_name] = M_R
#         results['Uniqueness'][method_name] = UI
#
#         # 打印每种方法的结果
#         print(f"{method_name} (UI): {UI:.8f}")
#         # print(f"  个体化值 (Fre): {Fre:.8f}")
#         # print(f"  单调性 (M(R)): {M_R:.8f}")
#
#
#     except Exception as e:
#         print(f"处理 {method_name} 时出错: {e}")
#
# for method_name, centrality_values in centrality_methods.items():
#     try:
#         # 计算个体化值
#         # Fre = calculate_individuation(centrality_values)
#         # # 计算单调性
#         M_R = calculate_monotonicity(centrality_values)
#         # # 计算独特性分数
#         # UI = calculate_uniqueness(centrality_values, p=2)
#
#         # 存储结果
#         # results['Individuation'][method_name] = Fre
#         results['Monotonicity'][method_name] = M_R
#         # results['Uniqueness'][method_name] = UI
#
#         # 打印每种方法的结果
#         # print(f"{method_name} (UI): {UI:.8f}")
#         # print(f"  个体化值 (Fre): {Fre:.8f}")
#         print(f"{method_name} (MR): {M_R:.8f}")
#
#
#     except Exception as e:
#         print(f"处理 {method_name} 时出错: {e}")




# 检查 SDGC 中心性值的出现次数，并按照次数排名
# def check_sdgc_centrality_distribution(centrality_values):
#     """
#     检查 SDGC 中心性值的出现次数，并按出现次数降序排名。
#     参数:
#     - centrality_values (dict or list): SDGC 中心性值。
#     返回:
#     - sorted_counts (list of tuples): 按出现次数排名的中心性值及其对应次数。
#     """
#     if isinstance(centrality_values, dict):
#         centrality_values = list(centrality_values.values())
#
#     # 统计每个中心性值的出现次数
#     score_counts = Counter(centrality_values)
#
#     # 按出现次数降序排序
#     sorted_counts = sorted(score_counts.items(), key=lambda x: x[1], reverse=True)
#
#     return sorted_counts
#
#
# # 只处理 SDGC 方法
# method_name = 'SDGC'
# abc = centrality_methods[method_name]
#
# # 计算 SDGC 中心性值的分布
# sdgc_distribution = check_sdgc_centrality_distribution(abc)
#
# # 输出结果
# print(f"SDGC 中心性值的出现次数排名：")
# print("-" * 40)
# for rank, (score, count) in enumerate(sdgc_distribution, 1):
#     print(f"排名 {rank}: 值 = {score:.60f}, 次数 = {count}")





# #绘制比较图
# plt.plot(centrality_eval, label='Gravity Model Centrality')
# plt.plot(degree_eval, label='Degree Centrality')
# plt.plot(closeness_eval, label='Closeness Centrality')
# ## plt.plot(pagerank_eval, label='PageRank Centrality')
# plt.plot(betweenness_eval, label='Betweenness Centrality')
# plt.plot(kshell_eval, label='kshell Centrality')
# plt.plot(egm_eval, label='EGM Centrality')
# plt.plot(lgc_eval, label='LGC Centrality')
# plt.plot(origravity_eval, label='Origravity Centrality')
# plt.xlabel('Number of nodes removed')
# plt.ylabel('Size of largest connected component')
# plt.legend()
# plt.show()
#


# 打印每种方法的排名结果
# def print_rankings(centrality_values, method_name):
#     sorted_nodes = sorted(centrality_values.items(), key=lambda item: item[1], reverse=True)
#     print(f"\nNodes sorted by {method_name}:")
#     for node, centrality in sorted_nodes:
#         print(f"Node {node}: Centrality {centrality}")
#     print("\n" + "="*50 + "\n")  # 分隔符
#
# print_rankings(centrality_values, "Gravity Model Centrality")
# print_rankings(degree_centrality, "Degree Centrality")
# print_rankings(closeness_centrality, "Closeness Centrality")
# print_rankings(pagerank_centrality, "PageRank Centrality")
# print_rankings(betweenness_centrality, "Betweenness Centrality")
# print_rankings(EGM_centrality_values, "EGM Centrality")
# print_rankings(lgc_centrality, "Laplacian Gravity Centrality")
# print_rankings(origravity_centrality, "Origravity Centrality")




# #  SI MODEL
# # SI模型仿真
#

# def select_initial_infected_nodes(centrality, percentage=0.03):  # 修改为 10%
#     num_initial_nodes = math.ceil(len(centrality) * percentage)  # 向上取整
#     sorted_nodes = sorted(centrality, key=centrality.get, reverse=True)
#     return sorted_nodes[:num_initial_nodes]
#
#
#
# def simulate_SI_model(G, initial_infected_nodes, beta, max_steps=50):
#     infected = set(initial_infected_nodes)
#     total_infected_curve = [0]  # 初始感染为 0
#
#     for step in range(max_steps):  # 循环 max_steps 次
#         new_infected = set()
#         for node in infected:
#             neighbors = G.neighbors(node)
#             for neighbor in neighbors:
#                 if neighbor not in infected and np.random.rand() < beta:
#                     new_infected.add(neighbor)
#
#         infected.update(new_infected)
#         total_infected_curve.append(len(infected))  # 第一步开始记录感染数
#
#     return total_infected_curve
#
#
#
#
# def run_SI_experiment(G, centrality, beta_values, num_experiments):
#     avg_infection_curves = {beta: [] for beta in beta_values}
#     top_nodes = select_initial_infected_nodes(centrality)
#
#     for beta in beta_values:
#         avg_curve = np.zeros(51)
#         for _ in range(num_experiments):
#             infection_curve = simulate_SI_model(G, top_nodes, beta)
#             avg_curve += np.array(infection_curve)
#         avg_infection_curves[beta] = avg_curve / num_experiments
#
#     return avg_infection_curves
#
#
# # 运行 SI 实验
# beta_values = [0.1]
# num_experiments = 100
#
# methods = {
#     'SDGC': centrality_values,
#     'DC': degree_centrality,
#     'CC': closeness_centrality,
#     # 'PR': pagerank_centrality,
#     'BC': betweenness_centrality,
#     'KS': k_shell_centrality,
#     'GC': origravity_centrality,
#     'EGM': EGM_centrality_values,
#     'LGC': lgc_centrality,
#     'AOGC':AOGC_centrality_values,
#     'FGM': FGM_centrality_values,
# }
#
# results = {}
# for method_name, method_centrality in methods.items():
#     avg_infection_curves = run_SI_experiment(G, method_centrality, beta_values, num_experiments)
#     for beta, infection_curve in avg_infection_curves.items():
#         results[(method_name, beta)] = infection_curve
#
#
#
# # 1. 修改后的可视化函数，按感染率 β 绘制单独的图像
# colors = ['b', 'g', 'r', 'c', 'm', 'y', 'k']
# linestyles = ['-', '--']
# markers = ['o', 's', 'D', '^', 'v', '<', '>', 'p', '*', 'X']
#
#
#
#
# def visualize_infection_curves_with_insets(results, beta_values, zoom_regions, show_insets=True):
#     for beta in beta_values:
#         fig, ax = plt.subplots(figsize=(8, 6), constrained_layout=True, dpi=300)
#
#         # 绘制主图
#         method_count = 0
#         for (method_name, beta_value), infection_curve in results.items():
#             if beta_value == beta:
#                 color = colors[method_count % len(colors)]
#                 linestyle = linestyles[method_count % len(linestyles)]
#                 marker = markers[method_count % len(markers)]
#
#                 ax.plot(
#                     range(len(infection_curve)),
#                     infection_curve,
#                     label=f'{method_name}',
#                     color=color,
#                     linestyle=linestyle,
#                     marker=marker,
#                     markevery=1,
#                     markersize=6,
#                     linewidth=2
#                 )
#                 method_count += 1
#
#         ax.set_xlim(-0.5, 50)
#         ax.set_ylim(0, max([max(curve) for (_, b), curve in results.items() if b == beta]) * 1.1)
#         ax.set_xlabel('Time t', fontsize=16)
#         ax.set_ylabel('Infected Nodes F(t)', fontsize=16)
#         ax.tick_params(axis='both', direction='in')
#         ax.legend(loc='best', framealpha=0.7)
#         ax.grid(False)
#         ax.set_title("USAir", fontsize=16)
#
#         # 自动分配放大图位置
#         if show_insets and zoom_regions:
#             inset_positions = ['upper right', 'lower right']
#
#             for i, (x_start, x_end, y_start, y_end) in enumerate(zoom_regions):
#                 position = inset_positions[i % len(inset_positions)]
#
#                 # 计算主图的横纵坐标范围的比例
#                 x_range = ax.get_xlim()[1] - ax.get_xlim()[0]
#                 y_range = ax.get_ylim()[1] - ax.get_ylim()[0]
#
#                 # 计算矩形框的宽度和高度，按主图坐标比例调整
#                 box_width = x_end - x_start  # 确保矩形框的宽度与放大区域相同
#                 box_height = y_end - y_start  # 确保矩形框的高度与放大区域相同
#
#                 # 保证矩形框的大小适中（避免过小或过大）
#                 box_width = max(box_width, 3)
#                 box_height = max(box_height, 30)
#
#                 # 计算矩形框的位置，使放大区域处于矩形框的中心
#                 box_x = x_start - (box_width - (x_end - x_start)) / 2
#                 box_y = y_start - (box_height - (y_end - y_start)) / 2
#
#                 # 添加矩形框，指示放大的区域
#                 ax.add_patch(Rectangle(
#                     (box_x, box_y),
#                     box_width,
#                     box_height,
#                     linewidth=0.6, edgecolor='black', facecolor='none', linestyle='-'
#                 ))
#
#                 # 创建放大图
#                 ax_inset = inset_axes(ax, width="30%", height="25%", loc=position, borderpad=8)
#
#                 method_count = 0
#                 for (method_name, beta_value), infection_curve in results.items():
#                     if beta_value == beta:
#                         color = colors[method_count % len(colors)]
#                         linestyle = linestyles[method_count % len(linestyles)]
#                         marker = markers[method_count % len(markers)]
#
#                         # 插值以支持小数范围
#                         original_x = np.arange(len(infection_curve))
#                         interpolator = interp1d(original_x, infection_curve, kind='linear', fill_value="extrapolate")
#                         x_values = np.linspace(x_start, x_end, 500)  # 插值为高分辨率数据点
#                         y_values = interpolator(x_values)
#
#                         ax_inset.plot(
#                             x_values,
#                             y_values,
#                             label=f'{method_name}',
#                             color=color,
#                             linestyle=linestyle,
#                             marker=None,  # 放大图不显示标记
#                             linewidth=1.5
#                         )
#                         method_count += 1
#
#                 # 设置放大图属性
#                 ax_inset.tick_params(axis='both', direction='in')
#                 ax_inset.set_xlim(x_start, x_end)
#                 ax_inset.set_ylim(y_start, y_end)
#                 ax_inset.grid(False)
#                 ax_inset.set_title('')
#
#         plt.show()
#
# # 调用可视化函数
# visualize_infection_curves_with_insets(
#     results,
#     beta_values,
#     zoom_regions=[
#         (1, 2, 75, 144),
#         (47, 49, 331, 332),
#     ],
#     show_insets=True
# )









#####最大连通分量
# 计算LCC大小
# def calculate_LCC(G):
#     if len(G) == 0:
#         return 0
#     largest_cc = max(nx.connected_components(G), key=len)
#     return len(largest_cc) / len(G)
#
# # 移除节点并计算LCC
# def sequential_node_removal(G, centrality, remove_fraction=0.7):  # 修改这里，设置默认移除70%的节点
#     sorted_nodes = sorted(centrality, key=centrality.get, reverse=True)
#     num_remove = min(int(len(G) * remove_fraction), len(sorted_nodes))  # 确保不会超出 sorted_nodes 的长度
#     lcc_sizes = []
#
#     G_copy = G.copy()  # 只复制一次
#
#     for i in range(num_remove):
#         G_copy.remove_node(sorted_nodes[i])
#         lcc_sizes.append(calculate_LCC(G_copy))
#
#     return lcc_sizes
#
# # 运行实验，移除节点并记录LCC
# def evaluate_robustness(G, centrality_methods):
#     lcc_results = {}
#
#     for method_name, centrality in centrality_methods.items():
#         print(f"正在进行 {method_name} 的节点移除实验...")
#         lcc_sizes = sequential_node_removal(G, centrality)
#         lcc_results[method_name] = lcc_sizes
#
#     return lcc_results
#
# # 绘制LCC曲线
# def plot_LCC_curves(lcc_results, show_inset=True):
#     plt.figure(figsize=(12, 8), dpi=150)
#     method_count = 0
#
#     colors = plt.get_cmap('tab20').colors
#     linestyles = ['-', '--']
#     markers = ['o', 's', 'D', '^', 'v', '<', '>', 'p', '*', 'X']
#
#     # 绘制主图
#     for method_name, lcc_sizes in lcc_results.items():
#         x_vals = np.linspace(0, 1, len(lcc_sizes))
#
#         # 设置颜色、线型和标记符号
#         color = tuple([c * 0.9 for c in colors[method_count % len(colors)]])
#         linestyle = linestyles[method_count % len(linestyles)]
#         marker = markers[method_count % len(markers)]
#
#         plt.plot(
#             x_vals,
#             lcc_sizes,
#             label=method_name,
#             color=color,
#             linestyle=linestyle,
#             markevery=5,
#             markersize=8,
#             linewidth=2
#         )
#         method_count += 1
#
#     # 设置主图的标签和标题
#     plt.xlabel('Fraction of nodes removed', fontsize=14)
#     plt.ylabel('Relative LCC size', fontsize=14)
#     plt.title('LCC Size After Node Removal', fontsize=16)
#     plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', frameon=True, fontsize=12)
#     # plt.grid(True, which='both', linestyle='--', linewidth=0.6)
#     plt.tight_layout()
#
#     # 添加嵌入式缩略图（根据 show_inset 参数决定是否绘制）
#     if show_inset:
#         ax_inset = inset_axes(plt.gca(), width="40%", height="40%", loc='upper right', borderpad=3)
#         method_count = 0  # 重新计数以确保嵌入图样式一致
#
#         # 绘制嵌入式缩略图
#         for method_name, lcc_sizes in lcc_results.items():
#             x_vals = np.linspace(0, 1, len(lcc_sizes))
#
#             color = tuple([c * 0.9 for c in colors[method_count % len(colors)]])
#             linestyle = linestyles[method_count % len(linestyles)]
#             marker = markers[method_count % len(markers)]
#
#             ax_inset.plot(
#                 x_vals,
#                 lcc_sizes,
#                 label=method_name,
#                 color=color,
#                 linestyle=linestyle,
#
#                 markevery=5,
#                 markersize=4,
#                 linewidth=2
#             )
#             method_count += 1
#
#         # 设置嵌入式缩略图的坐标轴范围
#         ax_inset.set_xlim(0, 0.2)
#         ax_inset.set_ylim(0.6, 1.0)
#         ax_inset.grid(True, linestyle='--', linewidth=0.5)
#         ax_inset.legend().set_visible(False)  # 隐藏嵌入图的图例
#
#     plt.show()
#
# # 调用绘图函数（示例）
# lcc_results = evaluate_robustness(G, centrality_methods)
# plot_LCC_curves(lcc_results, show_inset=False)








######correlation 相关性
# ##将 ndarray 转换为列表
# def convert_ndarray_to_list(infection_abilities):
#     # 将 infection_abilities 字典中的 ndarray 转换为 list
#     return {node: curve.tolist() if isinstance(curve, np.ndarray) else curve for node, curve in infection_abilities.items()}
#
# def save_infection_abilities_json(infection_abilities, filename):
#     # 先转换 ndarray 为 list
#     infection_abilities = convert_ndarray_to_list(infection_abilities)
#     with open(filename, 'w') as f:
#         json.dump(infection_abilities, f)
#
# def load_infection_abilities_json(filename):
#     with open(filename, 'r') as f:
#         infection_abilities = json.load(f)
#     return infection_abilities
#
# def simulate_SI_model(G, initial_infected_nodes, beta, max_steps=10):
#     infected = set(initial_infected_nodes)
#     total_infected_curve = []
#
#     for step in range(max_steps):
#         new_infected = set()
#         for node in infected:
#             neighbors = G.neighbors(node)
#             for neighbor in neighbors:
#                 if neighbor not in infected and np.random.rand() < beta:
#                     new_infected.add(neighbor)
#
#         infected.update(new_infected)
#         total_infected_curve.append(len(infected))  # 直接记录感染节点数量
#
#     return total_infected_curve
#
# def calculate_infection_abilities(G, centrality, beta_values, num_experiments=100):
#     infection_abilities = {}
#
#     for node in G.nodes:
#         avg_curve = np.zeros(10)  # 10个时间步
#         for _ in range(num_experiments):
#             infection_curve = simulate_SI_model(G, [node], 0.1)  # 固定感染概率为0.1
#             avg_curve += np.array(infection_curve)
#
#         infection_abilities[node] = avg_curve / num_experiments
#
#     return infection_abilities
#
# # 假设 G 和 centrality_values 已经定义并计算完成
# infection_abilities = calculate_infection_abilities(G, centrality_values, 0.1)
#
# # 定义保存路径
# save_path = r'img\Correlation\infectious.json'
#
# # 保存为 JSON 文件
# # save_infection_abilities_json(infection_abilities, save_path)
# #
# # # 如果已经保存过文件，可以直接加载
# # infection_abilities = load_infection_abilities_json(save_path)
#
#
# methods = {
#     'SDGC': centrality_values,
#     'DC': degree_centrality,
#     # 'CC': closeness_centrality,
#     'BC': betweenness_centrality,
#     # 'KS': k_shell_centrality,
#     # 'GC': origravity_centrality,
#     'EGM': EGM_centrality_values,
#     'LGC': lgc_centrality,
#     'AOGC': AOGC_centrality_values,
#     'FGM': FGM_centrality_values,
# }
#
# gravity_centrality = methods['SDGC']
#
# for method_name, comparison_centrality in methods.items():
#     if method_name != 'SDGC':
#         gravity_values = []
#         comparison_values = []
#         colors = []
#
#         for node in gravity_centrality.keys():
#             if node in comparison_centrality:
#                 gravity_values.append(gravity_centrality[node])
#                 comparison_values.append(comparison_centrality[node])
#                 infection_value = infection_abilities[node][-1]
#                 colors.append(infection_value)
#
#         if not gravity_values or not comparison_values:
#             print(f"没有足够的数据点用于{method_name}的比较。")
#             continue
#
#         min_infection = min(colors)
#         max_infection = max(colors)
#
#         plt.figure(figsize=(6.4, 4.8), dpi=450)
#         # 高分辨率
#         scatter = plt.scatter(
#             gravity_values,
#             comparison_values,
#             c=colors,
#             cmap='viridis',  # 深蓝到浅黄
#             marker='o',
#             s=15,
#             vmin=min_infection,
#             vmax=max_infection,
#         )
#         cbar = plt.colorbar(scatter)
#
#         # 调整右边距
#         plt.subplots_adjust(left=0.15, right=0.98, top=0.95, bottom=0.13)  # 将right设置为0.99，减少右边距
#
#         plt.clim(min_infection, max_infection)
#
#         # 设置更大更粗的字体
#         plt.xlabel('SDGC', fontsize=19, family='Arial')
#         plt.ylabel(f'{method_name}', fontsize=19, family='Arial')
#
#         # 设置坐标轴的范围
#         plt.xlim(min(gravity_values) * 1, max(gravity_values) * 1)
#         plt.ylim(min(comparison_values) * 1, max(comparison_values) * 1)
#
#         # 调整刻度标签的字体大小和加粗
#         plt.tick_params(axis='both', direction='in', labelsize=19, width=3)  # 增加刻度线宽度
#
#         plt.xticks(fontsize=22, fontweight='heavy', family='Times New Roman')  # 设置字体为Arial
#         plt.yticks(fontsize=22, fontweight='heavy', family='Times New Roman')  # 设置字体为Arial
#
#         # 增加坐标轴框的线宽
#         plt.gca().spines['top'].set_linewidth(2)
#         plt.gca().spines['right'].set_linewidth(2)
#         plt.gca().spines['left'].set_linewidth(2)
#         plt.gca().spines['bottom'].set_linewidth(2)
#
#         # 增大颜色条刻度的字体大小
#         cbar.ax.tick_params(labelsize=18, width=2)  # 增加颜色条数字的字体大小
#
#         # 保存图表为PDF格式到指定路径
#         # plt.savefig(rf'img\Correlation\jazz\{method_name}.pdf', format='pdf', bbox_inches='tight')  # f-string 格式化
#
#         # 显示图表
#         plt.show()




# # 假设你已有的中心性方法
# centrality_methods = {
#     'SDGC': centrality_values,
#     'DC': degree_centrality,
#     'CC': closeness_centrality,
#     'BC': betweenness_centrality,
#     'KS': k_shell_centrality,
#     'GC': origravity_centrality,
#     'EGM': EGM_centrality_values,
#     'LGC': lgc_centrality,
#     'AOGC': AOGC_centrality_values,
#     'FGM': FGM_centrality_values,
# }
#
# # 计算最大连通分量
# def calculate_LCC(G):
#     if len(G) == 0:
#         return 0
#     largest_cc = max(nx.connected_components(G), key=len)
#     return len(largest_cc)
#
# # 移除节点并计算LCC
# def sequential_node_removal(G, centrality, remove_fraction=0.7):
#     sorted_nodes = sorted(centrality, key=centrality.get, reverse=True)
#     num_remove = min(int(len(G) * remove_fraction), len(sorted_nodes))
#     lcc_sizes = []
#
#     G_copy = G.copy()  # 只复制一次
#
#     for i in range(num_remove):
#         G_copy.remove_node(sorted_nodes[i])
#         lcc_sizes.append(calculate_LCC(G_copy))
#
#     return lcc_sizes
#
# # 绘制3D柱状图
# def plot_3d_LCC_bar(lcc_results, remove_fractions=[0.1, 0.2, 0.3], rotation_angle=50):
#     fig = plt.figure(figsize=(5, 5), dpi=300)
#     ax = fig.add_subplot(111, projection='3d')
#
#     # 修改颜色，增强亮度
#     colors = plt.get_cmap('tab20').colors  # 配色方案
#     methods = list(lcc_results.keys())    # 获取所有中心性方法名称
#
#     # 定义Y轴和X轴的位置
#     y_vals = np.array(range(len(methods)))  # Y轴为中心性方法
#     x_vals = np.array(remove_fractions)    # X轴为移除节点比例（10%、20%、30%）
#
#     # 绘制柱状图
#     for i, method_name in enumerate(methods):
#         z_vals = lcc_results[method_name]  # 获取当前方法的LCC值
#
#         # 将颜色亮度提高
#         color = colors[i % len(colors)]
#         brighter_color = [min(c * 1.5, 1.0) for c in color]  # 增加亮度，防止超出最大值1.0
#
#         # 绘制柱状图
#         for j, fraction in enumerate(x_vals):
#             ax.bar3d(
#                 fraction,  # X轴位置：移除比例
#                 y_vals[i],  # Y轴位置：方法
#                 0,  # Z轴起始位置为0
#                 dx=0.0015,  # 每根柱子的宽度（在X轴方向）
#                 dy=0.75,   # 每根柱子的厚度（在Y轴方向）
#                 dz=z_vals[j],  # Z轴高度即为LCC值
#                 color=brighter_color,  # 每种方法的柱子颜色（亮度调整）
#                 alpha=0.7
#             )
#
#     # 设置坐标轴标签
#     ax.set_xlabel('Ratio of Removed Nodes', fontsize=12)
#     ax.set_zlabel('Size of Largest Component', fontsize=12)
#     ax.set_ylabel('Centrality Measures', fontsize=12)
#     ax.set_title('GrQc', fontsize=18)
#
#     # 设置Y轴为中心性方法
#     ax.set_yticks(y_vals)
#     ax.set_yticklabels(methods, fontsize=8)
#
#     # 设置X轴为移除节点的比例（10%、20%、30%）
#     ax.set_xticks(x_vals)
#     ax.set_xticklabels([f'{int(val*100)}%' for val in x_vals])
#
#     # 设置视角来改善光照效果
#     ax.view_init(azim=52, elev=20)  # 视角调整，仰角和方位角
#
#     # 获取坐标轴的当前变换
#     transform = ax.transData
#
#     # 创建一个旋转矩阵（顺时针旋转一定角度）
#     rotation_matrix = mtransforms.Affine2D().rotate_deg(rotation_angle)
#
#     # 应用旋转矩阵到坐标轴
#     ax.set_transform(rotation_matrix + transform)
#
#     # 显示图形
#     plt.show()
#
# # 运行实验，移除节点并记录LCC
# def evaluate_robustness(G, centrality_methods, remove_fractions=[0.1, 0.2, 0.3]):
#     lcc_results = {}
#
#     for method_name, centrality in centrality_methods.items():
#         print(f"正在进行 {method_name} 的节点移除实验...")
#         lcc_sizes = []
#         for remove_fraction in remove_fractions:
#             lcc_sizes.append(sequential_node_removal(G, centrality, remove_fraction)[-1])  # 每个比例的最终LCC
#         lcc_results[method_name] = lcc_sizes  # 将每个方法对应的LCC值保存
#
#     return lcc_results
#
# # 假设你已经有了一个图G和中心性方法字典 centrality_methods
# # 运行实验并绘制3D图
# lcc_results = evaluate_robustness(G, centrality_methods, remove_fractions=[0.1, 0.18, 0.3])
# plot_3d_LCC_bar(lcc_results)







