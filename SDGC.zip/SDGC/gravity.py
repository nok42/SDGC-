import networkx as nx
from collections import deque, defaultdict
import numpy as np


# 计算节点质量
def calculate_mass(G, node, closeness_centrality, core_number):
    neighbors_6 = list(nx.single_source_shortest_path_length(G, node, cutoff=6).keys())
    if node in neighbors_6:
        neighbors_6.remove(node)

    if not neighbors_6:
        return 0

    avg_closeness = np.mean([closeness_centrality[neigh] for neigh in neighbors_6])
    ks_i = core_number[node]
    mass = ((avg_closeness) ** 4.2) ** ((ks_i ) ** 0.1)
    return mass


# 计算万有引力常量
def calculate_gravitational_constant(ks_i, ks_j):
    return abs(ks_i - ks_j) + 1


# 在六度分隔范围内寻找所有路径
def bfs_paths_within_six_degrees(G, source, target):
    if source == target:
        return [[source]]

    predecessors = defaultdict(list)
    distances = {source: 0}
    queue = deque([source])
    max_degree = 6
    found = False

    while queue and not found:
        node = queue.popleft()
        current_distance = distances[node]

        if current_distance >= max_degree:
            break

        for neighbor in G.neighbors(node):
            if neighbor not in distances:
                distances[neighbor] = current_distance + 1
                queue.append(neighbor)

            if distances[neighbor] == current_distance + 1:
                predecessors[neighbor].append(node)

                if neighbor == target:
                    found = True

    def construct_paths(node):
        if node == source:
            return [[source]]
        paths = []
        for pred in predecessors[node]:
            for path in construct_paths(pred):
                paths.append(path + [node])
        return paths

    return construct_paths(target)


# 计算节点间距离
def calculate_distance(G, node1, node2, alpha=1):
    paths = bfs_paths_within_six_degrees(G, node1, node2)
    P_ij = len(paths)
    if P_ij == 0:
        return float('inf')
    L_ij = nx.shortest_path_length(G, source=node1, target=node2)
    num_nodes = G.number_of_nodes()
    return L_ij ** ((num_nodes / P_ij) ** alpha)


# 计算重力模型中心性
def calculate_centrality(G, alpha=1):
    G.remove_edges_from(nx.selfloop_edges(G))
    closeness_centrality = nx.closeness_centrality(G)
    core_number = nx.core_number(G)
    centrality = {}

    for node in G.nodes():
        C_i = 0
        neighbors_6 = nx.single_source_shortest_path_length(G, node, cutoff=6).keys()
        for neighbor in neighbors_6:
            if node != neighbor:
                m_i = calculate_mass(G, node, closeness_centrality, core_number)
                m_j = calculate_mass(G, neighbor, closeness_centrality, core_number)
                r_ij = calculate_distance(G, node, neighbor, alpha)
                G_ij = calculate_gravitational_constant(core_number[node], core_number[neighbor])
                if r_ij != float('inf'):
                    C_i += (G_ij ** 0.32) * ((m_i * m_j) / (r_ij ** 2))
        centrality[node] = C_i
        print(f"Node {node}: {C_i}")
    return centrality
